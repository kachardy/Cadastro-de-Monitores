package outros;
import pessoas.Aluno;
import pessoas.EnumSexo;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Programa {

	public static void main(String[] args) {
		Persistencia persistencia = new Persistencia();
		Scanner leitor = new Scanner(System.in);
		
		CentralDeInformacoes central = persistencia.recuperarCentral("central.xml");
        System.out.println("Central carregada com sucesso!");
        
        System.out.println("------------------------------------------");
        
        while (true) {
        	System.out.println("Opções:\n1-Cadastrar Aluno\n2-Listar Alunos\n"
        			+ "3-Buscar aluno específico\n4-Novo Edital\n5-Informar Quantidade de Editais Cadastrados\n"
        			+ "6-Detalhar Edital Específico\n7-Inscrever Aluno em vaga de Algum Edital\n"
        			+ "8-Gerar Relatório de um Aluno\nS-Sair");
        	
        	System.out.println("------------------------------------------");
        	
        	String opcao = leitor.nextLine();
        	
        	if (opcao.equals("1")) {
                System.out.print("Digite a matrícula: ");
                String matricula = leitor.nextLine();

                System.out.print("Digite o nome: ");
                String nome = leitor.nextLine();
                
                System.out.print("Digite o email: ");
                String email = leitor.nextLine();
                
                System.out.print("Digite a senha: ");
                String senha = leitor.nextLine();
                
                System.out.print("Digite o sexo (F/M): ");
                String entrada = leitor.nextLine().toUpperCase();
               
                EnumSexo sexo = Validador.validarSexo(entrada);
                
                if (sexo == null) {
                    System.out.println("Sexo inválido!");
                    continue;
                }
                
                Aluno novoAluno = new Aluno(nome, sexo, matricula, email, senha);

                if (central.adicionarAluno(novoAluno)) {
                    // salva a central novamente
                    persistencia.salvarCentral(central, "central.xml");
                }

            // --- opção 2: listar alunos ---
            } else if (opcao.equals("2")) {
                if (central.getTodosOsAlunos().isEmpty()) {
                    System.out.println("Nenhum aluno cadastrado ainda.");
                } else {
                    System.out.println("\n--- Alunos cadastrados ---");
                    for (Aluno a : central.getTodosOsAlunos()) {
                        System.out.println(a.getMatricula() + " - " + a.getNome());
                    }
                }

            // --- opção 3: buscar aluno ---
            } else if (opcao.equals("3")) {
                System.out.print("Digite a matrícula: ");
                String mat = leitor.nextLine();

                Aluno encontrado = central.recuperarAlunoPorMatricula(mat);

                if (encontrado != null) {
                    System.out.println("Aluno encontrado!");
                    System.out.println("Matrícula: " + encontrado.getMatricula());
                    System.out.println("Nome: " + encontrado.getNome());
                } else {
                    System.out.println("Aluno não encontrado!");
                }
                
            
                
            } else if (opcao.equalsIgnoreCase("4")) {
	            // Formatador de Data
	            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	            
	            System.out.println("Criando edital.....");
	            System.out.println("Digite o número do edital: ");
	            String numeroEdital = leitor.nextLine();
	            
	            System.out.print("Digite a data de início (dd/MM/yyyy): ");
	            LocalDate dataInicio = LocalDate.parse(leitor.nextLine(), formatter);
	            
	            System.out.print("Digite a data de fim (dd/MM/yyyy): ");
	            LocalDate dataFim = LocalDate.parse(leitor.nextLine(), formatter);
	            
	            EditalDeMonitoria edital = new EditalDeMonitoria(numeroEdital, dataInicio, dataFim);
	            central.adicionarEdital(edital);
	            
             
            } else if (opcao.equalsIgnoreCase("5")) {
            	System.out.println(central.getTodosOsEditais().toString());
                
            } else if (opcao.equalsIgnoreCase("6")) {
            	System.out.println("Digite o id do edital: ");
            	long id = Long.parseLong(leitor.nextLine());
            	
            	central.recuperarEditalPeloId(id);
               
            
            // Fazer a opção 7 e 8
            } else if (opcao.equalsIgnoreCase("7")) {
            	
             
            
            } else if (opcao.equalsIgnoreCase("8")) {
            	
            
            // --- sair ---
            } else if (opcao.equalsIgnoreCase("S")) { 
                System.out.println("Encerrando o programa...");
                break;

            } else {
                System.out.println("Opção inválida. Tente novamente.");
            }
        }
        leitor.close();
        System.out.println("Arquivo XML será salvo em: " + new java.io.File("central.xml").getAbsolutePath());

	}     
}
