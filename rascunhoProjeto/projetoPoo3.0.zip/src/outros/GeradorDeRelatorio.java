package outros;

import java.io.FileOutputStream;
import java.io.IOException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class GeradorDeRelatorio {
	public static void obterComprovanteDeInscricaoAluno(String matricula, long id, CentralDeInformacoes c) {
		 Document document = new Document();
		 try {

             PdfWriter.getInstance(document, new FileOutputStream("C:\\relatório.pdf"));
             document.open();

             document.add(new Paragraph(c.recuperarInscricoesDeUmAlunoEmUmEdital(matricula, id).toString()));
   }
         catch(DocumentException de) {
             System.err.println(de.getMessage());
         }
         catch(IOException ioe) {
             System.err.println(ioe.getMessage());
         }
         document.close();
     
	}
}
